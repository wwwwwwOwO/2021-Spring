本次实验将求解nbody问题，实现一个串行版本和MPI、OpenMP、pthread三种版本的解法。

Serial_solver.c、OpenMP_solver.c、Pthread_solver.c、MPI_solver.c分别为nbody问题的串行版本、OpenMP版本、Pthread版本、MPI版本的求解器。

nbody.txt为输入数据，请将其与求解器放置在同一目录下再编译运行。

由于上述4种版本的解法输出结果完全相同，故只提供一个输出文件nbody_last.txt。

