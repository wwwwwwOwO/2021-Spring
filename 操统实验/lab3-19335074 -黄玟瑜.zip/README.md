Assignment1·2的代码已在实验报告中给出，bootloader.asm为Assignment3的代码。

