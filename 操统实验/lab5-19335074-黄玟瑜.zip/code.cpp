int printf(const char *const fmt, ...)
{
    const int BUF_LEN = 32;
    char buffer[BUF_LEN + 1];
    char number[33];
    const char *s;
    char align_num[3];
    int idx, counter;
    va_list ap;
    va_start(ap, fmt);
    idx = 0;
    counter = 0;

    for (int i = 0; fmt[i]; ++i)
    {
        if (fmt[i] != '%')
        {
            counter += printf_add_to_buffer(buffer, fmt[i], idx, BUF_LEN);
            continue;
        }

        i++;
        if (fmt[i] == '\0')
            break;
        else if(fmt[i] == '-' || isdigit(fmt[i])){
            bool right = true;
            uint32 length = 0, mod = 0, addr;
            int align, align_length = 0;
            int temp;

            if(fmt[i]=='-'){
                right = false;
                i++;
            }

            //functions like strcpy
            while(isdigit(fmt[i])){
                align_num[align_length]=fmt[i];
                align_length++;
                i++;
            }
            align_num[align_length] = '\0';

            stoi(align_num, align, 10);


            switch (fmt[i])
            {
            case '%':
            case 'c':
                length = 1;
                break;
        
            case 's':
                s = va_arg(ap, const char *);
                while(s[length])
                    length++;
                break;
        
            case 'p':
                addr = va_arg(ap, uint32);
                number[0] = '0';
                number[1] = 'x';
                itos(number + 2, addr, 16);
                for (int j = 0; number[j]; ++j){
                    length++;   
                }
                break;
        
            case 'o': 
                if(mod == 0) mod = 8;
            case 'u':  
            case 'd': 
                if(mod == 0) mod = 10;
            case 'x':
                if(mod == 0) mod = 16;
        
                    temp = va_arg(ap, int);
                if (temp < 0 && fmt[i] == 'd')
                {
                    temp = -temp;
                    number[0] = '-';
                    itos(number + 1 , temp, mod);   
                }   
                else
                    itos(number, temp, mod);   
        
                for (int j = 0; number[j]; ++j){
                    length++;   
                }
            }
            align -= length;

            if(right)
                while(align > 0){
                    counter += printf_add_to_buffer(buffer, ' ', idx, BUF_LEN);
                    align--;
                }

            switch (fmt[i])
            {
            case '%':
                counter += printf_add_to_buffer(buffer, fmt[i], idx, BUF_LEN);
                break;

            case 'c':
                counter += printf_add_to_buffer(buffer, va_arg(ap, char), idx, BUF_LEN);
                break;

            case 's':
                buffer[idx] = '\0';
                idx = 0;
                counter += stdio.print(buffer);
                counter += stdio.print(s);
                break;

            case 'p':
            case 'd': 
            case 'o': 
            case 'u':  
            case 'x':

                for (int j = 0; number[j]; ++j)
                {
                    counter += printf_add_to_buffer(buffer, number[j], idx, BUF_LEN);
                }
            }

            while(align > 0){
                counter += printf_add_to_buffer(buffer, ' ', idx, BUF_LEN);
                align--;
            }
        }
        else{
            uint32 mod = 0;
            switch (fmt[i])
            {
            case '%':
                counter += printf_add_to_buffer(buffer, fmt[i], idx, BUF_LEN);
                break;

            case 'c':
                counter += printf_add_to_buffer(buffer, va_arg(ap, char), idx, BUF_LEN);
                break;

            case 's':
                buffer[idx] = '\0';
                idx = 0;
                counter += stdio.print(buffer);
                counter += stdio.print(va_arg(ap, const char *));
                break;

            case 'p':
                itos(number, va_arg(ap, uint32), 16);
                counter += printf_add_to_buffer(buffer, '0', idx, BUF_LEN);
                counter += printf_add_to_buffer(buffer, 'x', idx, BUF_LEN);
                for (int j = 0; number[j]; ++j)
                {
                    counter += printf_add_to_buffer(buffer, number[j], idx, BUF_LEN);
                }
                break;

            case 'o':
                if(mod == 0) mod = 8;
            case 'u':  
            case 'd': 
                if(mod == 0) mod = 10;
            case 'x':
                if(mod == 0) mod = 16;
                int temp = va_arg(ap, int);

                if (temp < 0 && fmt[i] == 'd')
                {
                    counter += printf_add_to_buffer(buffer, '-', idx, BUF_LEN);
                    temp = -temp;
                }

                itos(number, temp, mod);

                for (int j = 0; number[j]; ++j)
                {
                    counter += printf_add_to_buffer(buffer, number[j], idx, BUF_LEN);
                }
                break;
            }
        }
    }
    buffer[idx] = '\0';
    counter += stdio.print(buffer);
    return counter;

}



int isdigit(int c){
    return (c >= '0' && c <= '9');
}



void stoi(char *numStr, int &num, uint32 mod){
    if(mod != 10)
        return;

    num = 0;
    uint32 length = 0;
    uint32 radix = 1;
    
    while(numStr[length]){
        length++;
    }

    while(length){
        num += radix * (numStr[--length] - '0');
        radix *= 10;
    }
}

ListItem * ProgramManager::get_next_program(){
    ListItem *item = readyPrograms.front();
    if(readyPrograms.size() == 1)
        return item;

    PCB *ptr = ListItem2PCB(item, tagInGeneralList);
    ListItem *target_item = item;
    int max_priority = ptr->priority;

    item = item->next;
    while(item){
        ptr = ListItem2PCB(item, tagInGeneralList);
        if(ptr->priority > max_priority){
            max_priority = ptr->priority;
            target_item = item;
        }
        item = item->next;
    }
    return target_item;
}

void ProgramManager::schedule()
{
    bool status = interruptManager.getInterruptStatus();    // 获取中断管理器的当前状态
    interruptManager.disableInterrupt();

    if (readyPrograms.size() == 0)
    {
        interruptManager.setInterruptStatus(status);        // 恢复中断管理器的状态
        return;
    }

    if (running->status == ProgramStatus::RUNNING)
    {
        running->status = ProgramStatus::READY;
        running->ticks = running->priority * 10;
        readyPrograms.push_back(&(running->tagInGeneralList));
    }
    else if (running->status == ProgramStatus::DEAD)
    {
        releasePCB(running);
    }

    ListItem *item = get_next_program();                // 主要修改部分：获取下一个将要执行的线程
    PCB *next = ListItem2PCB(item, tagInGeneralList);
    PCB *cur = running;
    next->status = ProgramStatus::RUNNING;
    running = next;
    readyPrograms.erase(item);                          // 出队
    asm_switch_thread(cur, next);

    interruptManager.setInterruptStatus(status);
}

ListItem * ProgramManager::get_next_program(){
    ListItem *item = readyPrograms.front();
    if(readyPrograms.size() == 1)
        return item;

    PCB *ptr = ListItem2PCB(item, tagInGeneralList);
    ListItem *target_item = item;
    int min_duration = ptr->duration;

    item = item->next;
    while(item){
        ptr = ListItem2PCB(item, tagInGeneralList);
        if(ptr->duration < min_duration){
            min_duration = ptr->duration;
            target_item = item;
        }
        item = item->next;
    }
}