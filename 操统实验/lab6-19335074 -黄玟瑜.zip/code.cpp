//////////////////////////////////////////////////////////////// bts指令和lock前缀实现锁机制
asm_atomic_exchange:
    push ebp
    mov ebp, esp
    pushad
    mov ebx, [ebp + 4 * 3] ; memory 共享变量
    lock bts dword [ebx], 0
    jc asm_atomic_exchange_tag
    mov ebx, [ebp + 4 * 2] ;register
    mov dword[ebx], 0
asm_atomic_exchange_tag:
    popad
    pop ebp
    ret

//////////////////////////////////////////////////////////////// Race condition
int buffer[BUFFERSIZE];
int in = 0, out = 0;
int cur = 0;
void producer(void *arg)
{
    while(true){
        unsigned int delay = 10000000;
        while (delay){
            delay--;
        }
        buffer[in] = cur++;
        in = (in + 1) % BUFFERSIZE;
        printf("cur = %d\n", cur);        
    }
}
void consumer(void *arg)
{
    while(true){
        unsigned int delay = 9000000;
        while (delay){
            delay--;
        }
        buffer[out] = cur--;
        out = ( out + 1 ) % BUFFERSIZE;
        printf("cur = %d\n", cur);
    }
}



////////////////////////////////////////////////////////////////  生产者-消费者的信号量解决方案
Semaphore items, spaces;
int buffer[BUFFERSIZE];
int in = 0, out = 0;
int cur = 0;
void producer(void *arg)
{
    while(true){
        unsigned int delay = 7000000;
        while (delay){
            delay--;
        }
        spaces.P(); // 缓冲区有位置时才能append
        buffer[in] = cur++;
        in = (in + 1) % BUFFERSIZE;
        printf("cur = %d\n", cur);      
        items.V();  // 增加缓冲区内的元素个数
    }
}
void consumer(void *arg)
{
    while(true){
        unsigned int delay = 10000000;
        while (delay){
            delay--;
        }
        items.P();  // 缓冲区有数据时才能take
        buffer[out] = cur--;
        out = ( out + 1 ) % BUFFERSIZE;
        printf("cur = %d\n", cur);
        spaces.V(); // 释放空间
    }
}
void first_thread(void *arg)
{
    // 第1个线程不可以返回
    stdio.moveCursor(0);
    for (int i = 0; i < 25 * 80; ++i)
    {
        stdio.print(' ');
    }
    stdio.moveCursor(0);
    items.initialize(0);
    spaces.initialize(BUFFERSIZE);
    programManager.executeThread(producer, nullptr, "second thread", 1);
    programManager.executeThread(consumer, nullptr, "third thread", 1);
    asm_halt();
}



//////////////////////////////////////////////////////////////// 哲学家问题可能出现死锁的情况
#define T1 0
#define T2 100000000
// 屏幕IO处理器
STDIO stdio;
// 中断管理器
InterruptManager interruptManager;
// 程序管理器
ProgramManager programManager;
Semaphore chopsticks[5];
void phi0(void *arg){
    int id = 0;
    while(true){
        unsigned int delay;
        printf("No.%d start thinking...\n", id);
        delay = T1;
        while (delay)
        {
            delay--;
        }
        printf("No.%d thinking down.\n", id);
        chopsticks[id%5].P();
        printf("No.%d got right chopstick.\n", id);
        delay = T2;
        while (delay)
        {
            delay--;
        }
        chopsticks[(id+1)%5].P();
        printf("No.%d got both chopsticks.\n", id);
        delay = T1;
        while (delay)
        {
            delay--;
        }
        chopsticks[id%5].V();
        chopsticks[(id+1)%5].V();
        printf("No.%d finished eating.\n", id);
    }
}
void phi1(void *arg){
    int id = 1;
    while(true){
        unsigned int delay;
        printf("No.%d start thinking...\n", id);
        delay = T1;
        while (delay)
        {
            delay--;
        }
        printf("No.%d thinking down.\n", id);
        chopsticks[id%5].P();
        printf("No.%d got right chopstick.\n", id);
        delay = T2;
        while (delay)
        {
            delay--;
        }
        chopsticks[(id+1)%5].P();
        printf("No.%d got both chopsticks.\n", id);
        delay = T1;
        while (delay)
        {
            delay--;
        }
        chopsticks[id%5].V();
        chopsticks[(id+1)%5].V();
        printf("No.%d finished eating.\n", id);
    }
}
void phi2(void *arg){
    int id = 2;
    while(true){
        unsigned int delay;
        printf("No.%d start thinking...\n", id);
        delay = T1;
        while (delay)
        {
            delay--;
        }
        printf("No.%d thinking down.\n", id);
        chopsticks[id%5].P();
        printf("No.%d got right chopstick.\n", id);
        delay = T2;
        while (delay)
        {
            delay--;
        }
        chopsticks[(id+1)%5].P();
        printf("No.%d got both chopsticks.\n", id);
        delay = T1;
        while (delay)
        {
            delay--;
        }
        chopsticks[id%5].V();
        chopsticks[(id+1)%5].V();
        printf("No.%d finished eating.\n", id);
    }
}
void phi3(void *arg){
    int id = 3;
    while(true){
        unsigned int delay;
        printf("No.%d start thinking...\n", id);
        delay = T1;
        while (delay)
        {
            delay--;
        }
        printf("No.%d thinking down.\n", id);
        chopsticks[id%5].P();
        printf("No.%d got right chopstick.\n", id);
        delay = T2;
        while (delay)
        {
            delay--;
        }
        chopsticks[(id+1)%5].P();
        printf("No.%d got both chopsticks.\n", id);
        delay = T1;
        while (delay)
        {
            delay--;
        }
        chopsticks[id%5].V();
        chopsticks[(id+1)%5].V();
        printf("No.%d finished eating.\n", id);
    }
}
void phi4(void *arg){
    int id = 4;
    while(true){
        unsigned int delay;
        printf("No.%d start thinking...\n", id);
        delay = T1;
        while (delay)
        {
            delay--;
        }
        printf("No.%d thinking down.\n", id);
        chopsticks[id%5].P();
        printf("No.%d got right chopstick.\n", id);
        delay = T2;
        while (delay)
        {
            delay--;
        }
        chopsticks[(id+1)%5].P();
        printf("No.%d got both chopsticks.\n", id);
        delay = T1;
        while (delay)
        {
            delay--;
        }
        chopsticks[id%5].V();
        chopsticks[(id+1)%5].V();
        printf("No.%d finished eating.\n", id);
    }
}
void first_thread(void *arg)
{
    // 第1个线程不可以返回
    stdio.moveCursor(0);
    for (int i = 0; i < 25 * 80; ++i)
    {
        stdio.print(' ');
    }
    stdio.moveCursor(0);
    for(int i = 0; i < 5; i++){
        chopsticks[i].initialize(1);
    }
    programManager.executeThread(phi0, nullptr, "phi0", 1);
    programManager.executeThread(phi1, nullptr, "phi1", 1);
    programManager.executeThread(phi2, nullptr, "phi2", 1);
    programManager.executeThread(phi3, nullptr, "phi3", 1);
    programManager.executeThread(phi4, nullptr, "phi4", 1);
    asm_halt();
}





//////////////////////////////////////////////////////////////// 哲学家问题的解决方案
Semaphore chopsticks[5];
Semaphore num_chopstick;
void phi0(void *arg){
    int id = 0;
    while(true){
        unsigned int delay;
        printf("No.%d start thinking...\n", id);
        delay = T1;
        while (delay)
        {
            delay--;
        }
        printf("No.%d thinking down.\n", id);
        num_chopstick.P();
        chopsticks[id%5].P();
        printf("No.%d got right chopstick.\n", id);
        delay = T2;
        while (delay)
        {
            delay--;
        }
        chopsticks[(id+1)%5].P();
        printf("No.%d got both chopsticks.\n", id);
        delay = T1;
        while (delay)
        {
            delay--;
        }
        chopsticks[id%5].V();
        chopsticks[(id+1)%5].V();
        num_chopstick.V();
        printf("No.%d finished eating.\n", id);
    }
}

num_chopstick.initialize(4);