mbr.asm为Assignmen1的代码。

mbr2-1.asm、mbr2-2.asm、mbr2-3.asm分别为Assignmen2的2·1、2·2、2·3的代码。

student.asm为Assignmen3的代码。

mbr4为Assignmen4的代码。