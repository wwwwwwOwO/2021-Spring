asm_utils（src5）.asm为Assignment 2的代码，功能为进入 setup_kernel 函数后显示学号，用其替换实验指导lab4/src/5/utils/asm_utils.asm，在项目工程下make && make run即可运行。

asm_utils（src6）.asm为Assignment 3的代码，功能为触发默认的中断时显示字符弹射  ，用其替换实验指导lab6/src/5/utils/asm_utils.asm，在项目工程下make && make run即可运行。

interupt.cpp为Assignment 4的代码，功能为跑马灯显示学号，用其替换实验指导lab4/src/7/kernel/interupt.cpp，在项目工程下make && make run即可运行。

lab4-黄玟瑜-19335074.pdf为本次实验的实验报告。