function [Q,R] = householder(A)
[m,n] = size(A);
Q = eye(m,m);
R = A;

if m == n
    n = n-1;
end

for k = 1:n
    x = R(k:end,k);
    w = zeros(m-k+1,1);
    w(1) = norm(x);
    v = w-x;
    P = v*v'/(v'*v);
    H = eye(m,m);
    H(k:end,k:end) = H(k:end,k:end)-2*P;
    R = H*R;
    Q = Q*H;
end