function [value,vector] = getEigen(A,iter)
m = size(A,2);
vector = eye(m);
Q = eye(m);
R = A;

for k = 1:iter
    [Q,R] = householder(R*Q);
    vector = vector*Q;
end
value = diag(R*Q);