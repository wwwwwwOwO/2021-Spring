A1 = [3 -1 2;4 1 0;-3 2 1; 1 1 5;-2 0 3;];
A2 = [4 2 3 0;-2 3 -1 1;1 3 -4 2;1 0 1 -1;3 1 3 -2;];
[Q1,R1] = householder(A1);
[Q2,R2] = householder(A2);

B1 = A1*A1';
B2 = A2*A2';
[value1,vector1] = getEigen(B1,10000);
[value2,vector2] = getEigen(B2,10000);

v0 = [0.1;0.1;-0.1];
[v1] = newton(v0,5);
[v2] = broyden(v0,5);

