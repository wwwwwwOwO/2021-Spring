function [v] = newton(v,k)
syms x1 x2 x3;
F = [3*x1-cos(x2*x3)-0.5;
x1^2-81*(x2+0.1)^2+sin(x3)+1.06;
exp(-x1*x2)+20*x3+1/3*(10*3.14157-3);];
DF = jacobian(F);
for i = 1:k
    %disp(vpa(subs(DF,{x1,x2,x3},v'),4));
    %disp(vpa(subs(F,{x1,x2,x3},v'),4));
    v = v-vpa(subs(DF,{x1,x2,x3},v'),4)\vpa(subs(F,{x1,x2,x3},v'),4);
end
